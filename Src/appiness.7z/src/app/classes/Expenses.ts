export class Expense {
    id: Number;
    category: String;
    itemName: String;
    amount: Number;
    Date: any;
}